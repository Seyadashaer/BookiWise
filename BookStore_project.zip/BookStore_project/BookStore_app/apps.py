from django.apps import AppConfig


class BookstoreAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'BookStore_app'
